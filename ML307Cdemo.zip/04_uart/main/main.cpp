// main.cpp
#include "at_modem.h" // 引入 esp-ml307 组件的头文件
#include "esp_log.h"
#include "driver/gpio.h" // 包含 GPIO 头文件

static const char *TAG = "ML307C_DEMO";

// 将模组对象声明为静态全局变量，以便各个测试函数都能访问
static std::unique_ptr<AtModem> g_modem = nullptr;

// --- 各种测试函数的声明 ---
void InitializeModem();
void TestHttp();
void TestMqtt();
void TestWebSocket();
void TestTcp();
void TestUdp();
void TestDirectAtCommand();
void TestNetworkMonitor();
void TestEarlyRelease();
void TestErrorHandling();

extern "C" void app_main(void) {
	gpio_install_isr_service(0);
    ESP_LOGI(TAG, "开始初始化 ML307C 模组...");
    InitializeModem();

    if (!g_modem) {
        ESP_LOGE(TAG, "模组初始化失败，退出测试。");
        return;
    }

    ESP_LOGI(TAG, "\n=== 开始各项功能测试 ===\n");

    // 逐个调用测试函数
    TestHttp();
    TestTcp();
    TestUdp();
    TestMqtt();
   // TestWebSocket();
   // TestDirectAtCommand();
    TestNetworkMonitor();
    TestEarlyRelease();
   // TestErrorHandling();

    ESP_LOGI(TAG, "\n=== 所有测试完成 ===\n");
}

// --- 模组初始化函数 ---
void InitializeModem() {
    gpio_num_t ml307c_tx_pin = GPIO_NUM_17;
    gpio_num_t ml307c_rx_pin = GPIO_NUM_18;
    gpio_num_t ml307c_dtr_pin = GPIO_NUM_6;
    gpio_num_t ml307c_ri_pin = GPIO_NUM_7;

    ESP_LOGI(TAG, "正在检测 ML307C 模组...");
    g_modem = AtModem::Detect(ml307c_tx_pin, ml307c_rx_pin, ml307c_dtr_pin, ml307c_ri_pin, 115200);

    if (!g_modem) {
        ESP_LOGE(TAG, "模组检测失败或初始化失败！");
        return;
    }

     ESP_LOGI(TAG, "模组检测成功 (%s)，开始等待网络就绪...", g_modem->GetModuleRevision().c_str());

    NetworkStatus status = g_modem->WaitForNetworkReady(30000);
    if (status != NetworkStatus::Ready) {
        ESP_LOGE(TAG, "网络连接失败，错误码: %d", static_cast<int>(status));
        g_modem.reset(); // 初始化失败，清空指针
        return;
    }

    ESP_LOGI(TAG, "网络就绪！");
    ESP_LOGI(TAG, "模组版本: %s", g_modem->GetModuleRevision().c_str());
    ESP_LOGI(TAG, "IMEI: %s", g_modem->GetImei().c_str());
    ESP_LOGI(TAG, "ICCID: %s", g_modem->GetIccid().c_str());
    ESP_LOGI(TAG, "运营商: %s", g_modem->GetCarrierName().c_str());
    ESP_LOGI(TAG, "信号强度: %d", g_modem->GetCsq());
}

// --- HTTP 测试函数 ---
void TestHttp() {
    ESP_LOGI(TAG, "--- 开始 HTTP 测试 ---");
    if (!g_modem) {
        ESP_LOGE(TAG, "Modem 未初始化！");
        return;
    }

    auto http = g_modem->CreateHttp(0);
    if (http) {
        http->SetHeader("User-Agent", "Xiaozhi/3.0.0");
        http->SetTimeout(10000);

        if (http->Open("GET", "https://httpbin.org/json")) {
            ESP_LOGI(TAG, "HTTP 状态码: %d", http->GetStatusCode());
            ESP_LOGI(TAG, "响应内容长度: %zu bytes", http->GetBodyLength());

            std::string response = http->ReadAll();
            ESP_LOGI(TAG, "响应内容: %s", response.c_str());
        } else {
            ESP_LOGE(TAG, "HTTP 请求失败");
        }
        http->Close();
    } else {
        ESP_LOGE(TAG, "创建 HTTP 客户端失败");
    }
    ESP_LOGI(TAG, "--- HTTP 测试结束 ---\n");
}

// --- TCP 测试函数 ---
void TestTcp() {
    ESP_LOGI(TAG, "--- 开始 TCP 测试 ---");
    if (!g_modem) {
        ESP_LOGE(TAG, "Modem 未初始化！");
        return;
    }

    auto tcp = g_modem->CreateTcp(0);
    tcp->OnStream([](const std::string& data) {
        ESP_LOGI(TAG, "TCP 接收数据: %s", data.c_str());
    });

    if (tcp->Connect("httpbin.org", 80)) {
        std::string request = "GET /ip HTTP/1.1\r\nHost: httpbin.org\r\nConnection: close\r\n\r\n";
        int sent = tcp->Send(request);
        ESP_LOGI(TAG, "TCP 发送了 %d 字节", sent);
        vTaskDelay(pdMS_TO_TICKS(3000));
        tcp->Disconnect();
    } else {
        ESP_LOGE(TAG, "TCP 连接失败");
    }
    ESP_LOGI(TAG, "--- TCP 测试结束 ---\n");
}

// --- UDP 测试函数 ---
void TestUdp() {
    ESP_LOGI(TAG, "--- 开始 UDP 测试 ---");
    if (!g_modem) {
        ESP_LOGE(TAG, "Modem 未初始化！");
        return;
    }

    auto udp = g_modem->CreateUdp(0);
    udp->OnMessage([](const std::string& data) {
        ESP_LOGI(TAG, "UDP 接收数据: %s", data.c_str());
    });

    if (udp->Connect("8.8.8.8", 53)) { // Google DNS
        std::string test_data = "Hello UDP Server!";
        int sent = udp->Send(test_data);
        ESP_LOGI(TAG, "UDP 发送了 %d 字节", sent);
        vTaskDelay(pdMS_TO_TICKS(2000));
        udp->Disconnect();
    } else {
        ESP_LOGE(TAG, "UDP 连接失败");
    }
    ESP_LOGI(TAG, "--- UDP 测试结束 ---\n");
}

// --- MQTT 测试函数 ---
void TestMqtt() {
    ESP_LOGI(TAG, "--- 开始 MQTT 测试 ---");
    if (!g_modem) {
        ESP_LOGE(TAG, "Modem 未初始化！");
        return;
    }

    auto mqtt = g_modem->CreateMqtt(0);
    mqtt->OnConnected([]() {
        ESP_LOGI(TAG, "MQTT 连接成功");
    });
    mqtt->OnDisconnected([]() {
        ESP_LOGI(TAG, "MQTT 连接断开");
    });
    mqtt->OnMessage([](const std::string& topic, const std::string& payload) {
        ESP_LOGI(TAG, "收到消息 [%s]: %s", topic.c_str(), payload.c_str());
    });

    if (mqtt->Connect("broker.emqx.io", 1883, "esp32_client_" + g_modem->GetImei(), "", "")) {
        mqtt->Subscribe("test/esp32/message");
        mqtt->Publish("test/esp32/hello", "Hello from ESP32!");
        vTaskDelay(pdMS_TO_TICKS(5000));
        mqtt->Disconnect();
    } else {
        ESP_LOGE(TAG, "MQTT 连接失败");
    }
    ESP_LOGI(TAG, "--- MQTT 测试结束 ---\n");
}

// --- WebSocket 测试函数 ---
void TestWebSocket() {
    ESP_LOGI(TAG, "--- 开始 WebSocket 测试 ---");
    if (!g_modem) {
        ESP_LOGE(TAG, "Modem 未初始化！");
        return;
    }

    auto ws = g_modem->CreateWebSocket(0);
    ws->SetHeader("Protocol-Version", "3");
    ws->OnConnected([]() {
        ESP_LOGI(TAG, "WebSocket 连接成功");
    });
    ws->OnData([](const char* data, size_t length, bool binary) {
        ESP_LOGI(TAG, "收到数据: %.*s", (int)length, data);
    });
    ws->OnDisconnected([]() {
        ESP_LOGI(TAG, "WebSocket 连接断开");
    });
    ws->OnError([](int error) {
        ESP_LOGE(TAG, "WebSocket 错误: %d", error);
    });

    if (ws->Connect("wss://echo.websocket.org/")) {
        for (int i = 0; i < 3; i++) { // 发送 3 条消息
            std::string message = "{\"type\": \"ping\", \"id\": " + std::to_string(i) + "}";
            ws->Send(message);
            vTaskDelay(pdMS_TO_TICKS(1000));
        }
        ws->Close();
    } else {
        ESP_LOGE(TAG, "WebSocket 连接失败");
    }
    ESP_LOGI(TAG, "--- WebSocket 测试结束 ---\n");
}

// --- 直接 AT 命令测试函数 ---
void TestDirectAtCommand() {
    ESP_LOGI(TAG, "--- 开始 AT 命令测试 ---");
    if (!g_modem) {
        ESP_LOGE(TAG, "Modem 未初始化！");
        return;
    }

    auto uart = g_modem->GetAtUart();
    if (uart->SendCommand("AT+CSQ", 1000)) {
        std::string response = uart->GetResponse();
        ESP_LOGI(TAG, "信号强度查询结果: %s", response.c_str());
    } else {
        ESP_LOGE(TAG, "AT 命令执行失败");
    }
    ESP_LOGI(TAG, "--- AT 命令测试结束 ---\n");
}

// --- 网络监控测试函数 ---
void TestNetworkMonitor() {
    ESP_LOGI(TAG, "--- 开始 网络监控 测试 ---");
    if (!g_modem) {
        ESP_LOGE(TAG, "Modem 未初始化！");
        return;
    }

    g_modem->OnNetworkStateChanged([modem = g_modem.get()](bool ready) { // 捕获指针副本，防止 lambda 生命周期问题
        if (ready) {
            ESP_LOGI(TAG, "网络已就绪");
            ESP_LOGI(TAG, "信号强度: %d", modem->GetCsq());
            auto reg_state = modem->GetRegistrationState();
            ESP_LOGI(TAG, "注册状态: %s", reg_state.ToString().c_str());
        } else {
            ESP_LOGE(TAG, "网络连接丢失");
        }
    });

    // 立即检查一次
    if (g_modem->network_ready()) {
        ESP_LOGI(TAG, "当前网络状态: 已连接");
    } else {
        ESP_LOGI(TAG, "当前网络状态: 未连接");
    }
    vTaskDelay(pdMS_TO_TICKS(2000)); // 观察回调效果
    ESP_LOGI(TAG, "--- 网络监控 测试结束 ---\n");
}

// --- 提前释放测试函数 ---
void TestEarlyRelease() {
    ESP_LOGI(TAG, "--- 开始 早期释放 测试 ---");
    if (!g_modem) {
        ESP_LOGE(TAG, "Modem 未初始化！");
        return;
    }

    {
        auto http = g_modem->CreateHttp(0);
        if(http) {
            ESP_LOGI(TAG, "创建 HTTP 对象");
            http->Close();
            http.reset(); // 显式释放
            ESP_LOGI(TAG, "HTTP 对象已重置");
        }
    } // 作用域结束，http (如果存在) 自动销毁

    // 尝试创建新对象验证内存管理
    auto tcp = g_modem->CreateTcp(0);
    if(tcp) {
        ESP_LOGI(TAG, "创建 TCP 对象成功 (验证内存未泄露)");
        tcp->Disconnect();
    }
    ESP_LOGI(TAG, "--- 早期释放 测试结束 ---\n");
}

// --- 错误处理测试函数 ---
void TestErrorHandling() {
    ESP_LOGI(TAG, "--- 开始 错误处理 测试 ---");
    if (!g_modem) {
        ESP_LOGE(TAG, "Modem 未初始化！");
        return;
    }

    // 这里模拟一个错误场景，比如尝试连接一个不存在的服务器
    auto tcp = g_modem->CreateTcp(0);
    if (!tcp->Connect("thisdomaindoesnotexist.local", 80)) {
        ESP_LOGI(TAG, "连接不存在的服务器失败，符合预期。");
        // 可以在这里检查具体的错误码，但组件可能不直接暴露
    }
    ESP_LOGI(TAG, "--- 错误处理 测试结束 ---\n");
}