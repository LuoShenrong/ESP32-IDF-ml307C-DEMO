#ifndef __UART_H_
#define __UART_H_

#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/uart.h"
#include "driver/uart_select.h"
#include "driver/gpio.h"

/* 主串口配置 - 连接电脑串口助手 */
#define PC_USART_UART_NUM UART_NUM_0
#define PC_USART_TX_GPIO_PIN GPIO_NUM_43
#define PC_USART_RX_GPIO_PIN GPIO_NUM_44

/* 蓝牙串口配置 - 连接JDY-31蓝牙模块 */
#define BT_USART_UART_NUM UART_NUM_1
#define BT_USART_TX_GPIO_PIN GPIO_NUM_17
#define BT_USART_RX_GPIO_PIN GPIO_NUM_18

#define RX_BUF_SIZE 1024 
#define TX_BUF_SIZE 1024

void pc_usart_init(uint32_t baudrate);
void bt_usart_init(uint32_t baudrate);

#endif